package math;

public class Variable implements IExpression {

	public Variable() {
	}

	public Variable(String varName) {
		new Variable();
	}

	public int evaluate(int arg) {
		return arg;
	}
}

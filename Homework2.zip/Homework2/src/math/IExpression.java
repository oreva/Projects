package math;

public interface IExpression {
	int evaluate(int arg);
}
